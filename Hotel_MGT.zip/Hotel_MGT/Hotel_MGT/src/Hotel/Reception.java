package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reception extends JFrame implements ActionListener {
    JButton newcust,rooms,department,allemployee,managerInfo,customers,findroom,updatesta,updatestaroom,pickup,checkout,logout;
    Reception(){

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

         newcust =new JButton("New Customer Form");
        newcust.setBounds(10,30,200,30);
        newcust.setBackground(Color.BLACK);
        newcust.setForeground(Color.WHITE);
        newcust.addActionListener(this);
       add(newcust);

        rooms =new JButton("Rooms ");
       rooms.setBounds(10,70,200,30);
        rooms.setBackground(Color.BLACK);
        rooms.setForeground(Color.WHITE);
        rooms.addActionListener(this);
       add(rooms);


        department =new JButton("Department ");
        department.setBounds(10,110,200,30);
        department.setBackground(Color.BLACK);
        department.setForeground(Color.WHITE);
        department.addActionListener(this);
        add(department);


        allemployee =new JButton("All Employee ");
       allemployee.setBounds(10,150,200,30);
        allemployee.setBackground(Color.BLACK);
        allemployee.setForeground(Color.WHITE);
        allemployee.addActionListener(this);
        add(allemployee);


        customers  =new JButton("Customer Info ");
        customers.setBounds(10,190,200,30);
        customers.setBackground(Color.BLACK);
        customers.setForeground(Color.WHITE);
        customers.addActionListener(this);
        add(customers);


        managerInfo  =new JButton("Manager Info");
        managerInfo.setBounds(10,230,200,30);
        managerInfo.setBackground(Color.BLACK);
        managerInfo.setForeground(Color.WHITE);
        managerInfo.addActionListener(this);
        add(managerInfo);

        checkout  =new JButton("Checkout");
        checkout.setBounds(10,270,200,30);
        checkout.setBackground(Color.BLACK);
        checkout.setForeground(Color.WHITE);
        checkout.addActionListener(this);
        add(checkout);

        updatesta  =new JButton("Update Status");
        updatesta.setBounds(10,310,200,30);
        updatesta.setBackground(Color.BLACK);
        updatesta.setForeground(Color.WHITE);
        updatesta.addActionListener(this);
        add(updatesta);

        updatestaroom  =new JButton("Update Room Status");
        updatestaroom.setBounds(10,350,200,30);
        updatestaroom.setBackground(Color.BLACK);
        updatestaroom.setForeground(Color.WHITE);
        updatestaroom.addActionListener(this);
        add(updatestaroom);


        pickup  =new JButton("Pickup Services");
        pickup.setBounds(10,390,200,30);
        pickup.setBackground(Color.BLACK);
        pickup.setForeground(Color.WHITE);
        pickup.addActionListener(this);
        add(pickup);



        findroom  =new JButton("Search Room");
        findroom.setBounds(10,430,200,30);
        findroom.setBackground(Color.BLACK);
        findroom.setForeground(Color.WHITE);
        findroom.addActionListener(this);
        add(findroom);

        logout  =new JButton("Logout");
        logout.setBounds(10,470,200,30);
        logout.setBackground(Color.BLACK);
        logout.setForeground(Color.WHITE);
        logout.addActionListener(this);
        add(logout);



        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/fourth.jpg"));
        JLabel img=new JLabel(i1);
        img.setBounds(250,30,500,470 );
        add(img);


        setBounds(350,150,800,570);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e) {
            if (e.getSource() == newcust){
                setVisible(false);
                new AddCustomer();
            } else if (e.getSource() == rooms ) {
                setVisible(false);
                new AllRooms();
            } else if (e.getSource() == department) {
                setVisible(false);
                new Department();
            } else if (e.getSource() == allemployee) {
                setVisible(false);
                new Employeeinfo();
            } else if (e.getSource() == managerInfo) {
                setVisible(false);
                new managerinfo();
            } else if (e.getSource() == customers) {
                setVisible(false);
                new Customerinfo();
            } else if (e.getSource() == findroom) {
                setVisible(false);
                new Searchroom();
            } else if (e.getSource() == updatesta) {
                setVisible(false);
                new UpdateCheck();
            } else if (e.getSource() == updatestaroom) {
                setVisible(false);
                new UpdateRoom();
            } else if (e.getSource() == pickup) {
                setVisible(false);
                new SearchDriver();
            } else if (e.getSource() == checkout) {
                setVisible(false);
                new Checkout();
            } else if (e.getSource() == logout) {
                setVisible(false);
                new Login();
            }
    }

    public static void main(String[] args) {
        new Reception();
    }


}

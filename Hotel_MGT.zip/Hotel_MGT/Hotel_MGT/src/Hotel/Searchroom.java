package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import net.proteanit.sql.DbUtils;

public class Searchroom extends JFrame implements ActionListener {
    JTable table;
    JButton back, submit;
    JComboBox bedtype;
    JCheckBox available;

    Searchroom() {
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel text = new JLabel("Search for Room");
        text.setFont(new Font("Tahoma", Font.BOLD, 40));
        text.setBounds(250, 20, 500, 50);
        add(text);

        JLabel roomlb = new JLabel("Bed Type");
        roomlb.setFont(new Font("Tahoma", Font.PLAIN, 16));
        roomlb.setBounds(150, 90, 100, 30);
        add(roomlb);

        bedtype = new JComboBox(new String[]{"Single", "Double"});
        bedtype.setBounds(250, 90, 150, 25);
        bedtype.setBackground(Color.WHITE);
        add(bedtype);

        available = new JCheckBox("Only display Available");
        available.setBackground(Color.WHITE);
        available.setBounds(450, 90, 200, 25);
        add(available);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 160, 750, 300);
        add(scrollPane);

        try {
            conn c = new conn();
            ResultSet rs = c.s.executeQuery("select * from room");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        submit = new JButton("Submit");
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        submit.setBounds(200, 500, 100, 40);
        add(submit);

        back = new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(400, 500, 100, 40);
        add(back);

        setBounds(400, 150, 800, 600);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submit) {
            try {
                String query = "select * from room where type='" + bedtype.getSelectedItem() + "'";
                String query2 = "select * from room where avaibility='Available' AND type='" + bedtype.getSelectedItem() + "'";

                conn con = new conn();
                ResultSet rs;

                if (available.isSelected()) {
                    rs = con.s.executeQuery(query2);
                } else {
                    rs = con.s.executeQuery(query);
                }

                table.setModel(DbUtils.resultSetToTableModel(rs));

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == back) {
            setVisible(false);
            new Reception();
        }
    }

    public static void main(String[] args) {
        new Searchroom();
    }
}

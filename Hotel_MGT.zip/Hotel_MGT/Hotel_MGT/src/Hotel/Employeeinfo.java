package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.*;

public class Employeeinfo extends JFrame implements ActionListener {
    JTable table;
    JButton back;
    Employeeinfo(){

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);


        table=new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50,50,950,500);
        add(scrollPane);


//        JLabel name=new JLabel("Name");
//        name.setBounds(80,20,100,20);
//        add(name);
//
//        JLabel age=new JLabel("Age");
//        age.setBounds(190,20,100,20);
//        add(age);
//
//        JLabel gender=new JLabel("Gender");
//        gender.setBounds(310,20,100,20);
//        add(gender);
//
//        JLabel job=new JLabel("Job Position");
//        job.setBounds(425,20,100,20);
//        add(job);
//
//        JLabel salary=new JLabel("Salary");
//        salary.setBounds(550,20,100,20);
//        add(salary);
//
//        JLabel cno=new JLabel("Contact No");
//        cno.setBounds(670,20,100,20);
//        add(cno);
//
//        JLabel email=new JLabel("E-Mail");
//        email.setBounds(790,20,100,20);
//        add(email);
//
//        JLabel aadhar=new JLabel("Aadhaar No");
//        aadhar.setBounds(900,20,100,20);
//        add(aadhar);


        try{
            conn c=new conn();
            ResultSet rs=c.s.executeQuery("select * from employee");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(450, 550, 100, 40);
        add(back);

        setBounds(300,130,1050,650);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
        new Reception();
    }

    public static void main(String[] args) {
        new Employeeinfo();
    }
}

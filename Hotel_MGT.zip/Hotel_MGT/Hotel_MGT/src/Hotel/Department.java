package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.*;

public class Department extends JFrame implements ActionListener {
    JTable table;
    JButton back;
    Department(){

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);


        table=new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50,40,400,300);
        add(scrollPane);


//        JLabel roomno=new JLabel("Department");
//        roomno.setBounds(100,20,100,20);
//        add(roomno);
//
//
//        JLabel available=new JLabel("Budget");
//        available.setBounds(350,20,100,20);
//        add(available);


        try{
            conn c=new conn();
            ResultSet rs=c.s.executeQuery("select * from department");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(250, 350, 100, 40);
        add(back);

        setBounds(300,130,600,500);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
        new Reception();
    }

    public static void main(String[] args) {
        new Department();
    }
}

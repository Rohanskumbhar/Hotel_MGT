package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddDrivers extends JFrame implements ActionListener {
    JButton add,cancel;
    JTextField nametext,agetext,companytext,modeltext,locationtext;
    JComboBox availableornot,gender1;

    AddDrivers(){
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setBounds(200,100,1100,500);
        setVisible(true);

        JLabel heading =new JLabel("Add Drivers");
        heading.setFont(new Font("Tahoma",Font.BOLD,30));
        heading.setBounds(450,10,200,50);
        add(heading);

        //Room Start
        JLabel name =new JLabel("Name :- ");
        name.setFont(new Font("Tahoma",Font.PLAIN ,16));
        name.setBounds(80,70,160,30);
        add(name);

        nametext=new JTextField();
        nametext.setBounds(260,70,200,30);
        nametext.setFont(new Font("Tahoma",Font.PLAIN ,14));
        add(nametext);
        //Room End

        //Age
        JLabel available =new JLabel("Age :- ");
        available.setFont(new Font("Tahoma",Font.PLAIN ,16));
        available.setBounds(80,110,160,30);
        add(available);

        agetext=new JTextField();
        agetext.setBounds(260,110,200,30);
        agetext.setFont(new Font("Tahoma",Font.PLAIN ,14));
        add(agetext);

        //Gender
        JLabel gender =new JLabel("Gender :- ");
        gender.setFont(new Font("Tahoma",Font.PLAIN ,16));
        gender.setBounds(80,150,160,30);
        add(gender);

        String cleanoptions[]={"Male","Female"};
        gender1=new JComboBox(cleanoptions);
        gender1.setBounds(260,150,160,30);
        gender1.setBackground(Color.WHITE);
        add(gender1);


        //Car Company
        JLabel Company =new JLabel("Car Company :- ");
        Company.setFont(new Font("Tahoma",Font.PLAIN ,16));
        Company.setBounds(80,190,160,30);
        add(Company);

        companytext=new JTextField();
        companytext.setBounds(260,190,200,30);
        companytext.setFont(new Font("Tahoma",Font.PLAIN ,14));
        add(companytext);

        // Car Model
        JLabel car =new JLabel(" Car Model :- ");
        car.setFont(new Font("Tahoma",Font.PLAIN ,16));
        car.setBounds(80,230,160,30);
        add(car);

        modeltext=new JTextField();
        modeltext.setBounds(260,230,200,30);
        modeltext.setFont(new Font("Tahoma",Font.PLAIN ,14));
        add(modeltext);

        //Available or not
        JLabel available1 =new JLabel("Available :- ");
        available1.setFont(new Font("Tahoma",Font.PLAIN ,16));
        available1.setBounds(80,270,160,30);
        add(available1);

        String availableoptions[]={"Available","Busy"};
        availableornot=new JComboBox(availableoptions);
        availableornot.setBounds(260,270,160,30);
        availableornot.setBackground(Color.WHITE);
        add(availableornot);

        // Location
        JLabel Location =new JLabel(" Location :- ");
        Location.setFont(new Font("Tahoma",Font.PLAIN ,16));
        Location.setBounds(80,310,160,30);
        add(Location);

        locationtext=new JTextField();
        locationtext.setBounds(260,310,200,30);
        locationtext.setFont(new Font("Tahoma",Font.PLAIN ,14));
        add(locationtext);



        add=new JButton("Add Driver");
        add.setForeground(Color.WHITE);
        add.setBackground(Color.BLACK);
        add.setBounds(150,350,100,30);
        add.addActionListener(this);
        add(add);

        cancel=new JButton("Cancel");
        cancel.setForeground(Color.WHITE);
        cancel.setBackground(Color.BLACK);
        cancel.setBounds(350,350,80,30);
        cancel.addActionListener(this);
        add(cancel);

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icons/eleven.jpg"));
        Image i2=i1.getImage().getScaledInstance(500,380,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(500,70,500,350);
        add(img);


    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == add){
            String name=nametext.getText();
            String age=(String) agetext.getText();
            String gender=(String) gender1.getSelectedItem();
            String company=companytext.getText();
            String model=(String) modeltext.getText();
            String avaibility2 =(String) availableornot.getSelectedItem();
            String location=locationtext.getText();


            try {
                conn con=new conn();

                String query="insert into drivers values('"+name+"','"+age+"','"+gender+"','"+company+"','"+model+"','"+avaibility2+"','"+location+"') ";

                con.s.executeUpdate(query);

                JOptionPane.showMessageDialog(null,"New Driver Added Successfully");
                setVisible(false);


            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == cancel) {
            setVisible(false);
        }

    }

    public static void main(String[] args) {
        new AddDrivers();
    }


}

package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public  class Hotel extends JFrame implements ActionListener{

    Hotel() {
//        setSize(1200, 550);
//        setLocation(150,150);
        setBounds(150,150,1200,550);//use this or use commentdown lines

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/first.jpg"));
        JLabel img1=new JLabel(i1);
        add(img1);
        img1.setBounds(0,0,1200,550);//1)loc-X2,)loc-Y,3)width,4)Height



        JLabel text=new JLabel("Hotel Management System");
        text.setBounds(20,400,1200,150);
        text.setForeground(Color.white);
        text.setFont(new Font("serif",Font.BOLD,50));
        img1.add(text);

        JButton button=new JButton("Next");
        button.setBounds(1050,450,80,40);
        button.setBackground(Color.PINK);
        button.addActionListener(this);
        button.setFont(new Font("plain",Font.BOLD,20));
        img1.add(button);

        setVisible(true);

        while (true){
            text.setVisible(false);
            try{
                 Thread.sleep(500);
            }catch(Exception e){
                e.printStackTrace();
            }
            text.setVisible(true);
            try{
                Thread.sleep(500);
            }catch(Exception e){
                e.printStackTrace();
            }
        }


    }

    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Login();
    }
    public static void main(String[] args) {
         new Hotel();
    }
}

package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.*;

public class AllRooms extends JFrame implements ActionListener {
    JTable table;
    JButton back;
    AllRooms(){

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/eight.jpg"));
        Image i2 = i1.getImage().getScaledInstance(600,600,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(500,0,600,600);
        add(img);

        table=new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0,40,500,400);
        add(scrollPane);


//        JLabel roomno=new JLabel("Room Number");
//        roomno.setBounds(5,20,100,20);
//        add(roomno);
//
//
//        JLabel available=new JLabel("Availability");
//        available.setBounds(110,20,100,20);
//        add(available);
//
//
//        JLabel clean=new JLabel("Cleaning Status");
//        clean.setBounds(205,20,100,20);
//        add(clean);
//
//        JLabel price=new JLabel("Price");
//        price.setBounds(315,20,100,20);
//        add(price);
//
//        JLabel bedtype=new JLabel("Bed Type");
//        bedtype.setBounds(405,20,100,20);
//        add(bedtype);





        try{
            conn c=new conn();
            ResultSet rs=c.s.executeQuery("select * from room");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(200, 460, 100, 40);
        add(back);

        setBounds(300,130,1050,600);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
            setVisible(false);
            new Reception();
    }

    public static void main(String[] args) {
        new AllRooms();
    }
}

package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.*;

public class Customerinfo extends JFrame implements ActionListener {
    JTable table;
    JButton back;
    Customerinfo(){

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);


        table=new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50,50,950,500);
        add(scrollPane);


//        JLabel name=new JLabel("Document");
//        name.setBounds(80,20,100,20);
//        add(name);
//
//        JLabel age=new JLabel("ID-Number");
//        age.setBounds(190,20,100,20);
//        add(age);
//
//        JLabel gender=new JLabel("Name");
//        gender.setBounds(320,20,100,20);
//        add(gender);
//
//        JLabel job=new JLabel("Gender");
//        job.setBounds(435,20,100,20);
//        add(job);
//
//        JLabel salary=new JLabel("Nationality");
//        salary.setBounds(550,20,100,20);
//        add(salary);
//
//        JLabel cno=new JLabel("Room No");
//        cno.setBounds(670,20,100,20);
//        add(cno);
//
//        JLabel email=new JLabel("Check In Time");
//        email.setBounds(780,20,100,20);
//        add(email);
//
//        JLabel aadhar=new JLabel("Price");
//        aadhar.setBounds(900,20,100,20);
//        add(aadhar);


        try{
            conn c=new conn();
            ResultSet rs=c.s.executeQuery("select * from customer");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(450, 550, 100, 40);
        add(back);

        setBounds(300,130,1050,650);
        setVisible(true);

    }
    public void actionPerformed(ActionEvent e) {
        setVisible(false);
        new Reception();
    }

    public static void main(String[] args) {
        new Customerinfo();
    }
}

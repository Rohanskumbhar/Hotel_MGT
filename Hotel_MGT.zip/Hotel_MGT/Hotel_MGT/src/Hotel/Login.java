package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener {

    JTextField username;
    JPasswordField enterpass;
    JButton login, cancel;

    Login() {
        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(90, 40, 200, 100);
        userLabel.setFont(new Font("Arial", Font.BOLD, 20));
        userLabel.setForeground(Color.WHITE);
        add(userLabel);

        username = new JTextField();
        username.setBounds(220, 77, 200, 30);
        add(username);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(90, 120, 200, 100);
        passLabel.setFont(new Font("Arial", Font.BOLD, 20));
        passLabel.setForeground(Color.WHITE);
        add(passLabel);

        enterpass = new JPasswordField();
        enterpass.setBounds(220, 155, 200, 30);
        add(enterpass);

        login = new JButton("Login");
        login.setBounds(160, 250, 90, 35);
        login.setBackground(Color.BLACK);
        login.setFont(new Font("Arial", Font.BOLD, 18));
        login.setForeground(Color.WHITE);
        login.addActionListener(this);
        add(login);

        cancel = new JButton("Cancel");
        cancel.setBounds(270, 250, 140, 35);
        cancel.setBackground(Color.BLACK);
        cancel.setFont(new Font("Arial", Font.BOLD, 18));
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        add(cancel);

        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("icons/second.jpg"));
        Image icon1 = icon.getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT);
        ImageIcon icon2 = new ImageIcon(icon1);
        JLabel img = new JLabel(icon2);
        img.setBounds(500, 50, 250, 220);
        add(img);

        setBounds(400, 250, 800, 400);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == login) {
            String user = username.getText().trim();
            String pass = String.valueOf(enterpass.getPassword()).trim();

            try {
                conn cc = new conn(); // Make sure this connects properly

                String query = "SELECT * FROM login WHERE username='" + user + "' AND password='" + pass + "'";
                ResultSet resultSet = cc.s.executeQuery(query);

                if (resultSet.next()) {
                    setVisible(false);
                    JOptionPane.showMessageDialog(null, "Login Successful!");
                     new Dashboard();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Username or Password");
                }

            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database connection error: " + e.getMessage());
            }
        } else if (ae.getSource() == cancel) {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Login();
    }
}

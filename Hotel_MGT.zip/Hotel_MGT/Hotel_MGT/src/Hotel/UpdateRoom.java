package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;


public class UpdateRoom extends JFrame implements ActionListener {

    Choice customer;
    JTextField troomno,tstatus,tavailable,tname,checkintime2,tdepo;
    JButton check,update,back;
    UpdateRoom(){
        setBounds(300,150,980,450);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);

        JLabel text=new JLabel("Update Room Status");
        text.setFont(new Font("Tahoma",Font.BOLD,25));
        text.setBounds(180,20,300,30);
        add(text);

        JLabel cust=new JLabel("Customer Id");
        cust.setBounds(60,95,100,30);
        add(cust);

        customer =new Choice();
        customer.setBounds(200,95,150,30);
        add(customer);

        try{
            conn c=new conn();
            ResultSet rs=c.s.executeQuery("select * from customer");
            while (rs.next()){
                customer.add(rs.getString("number"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        JLabel room=new JLabel("Room Number");
        room.setBounds(60,125,100,30);
        add(room);

        troomno=new JTextField();
        troomno.setBounds(200,125,150,30);
        add(troomno);

        JLabel checkin=new JLabel("Availability");
        checkin.setBounds(60,215,100,30);
        add(checkin);

        tavailable=new JTextField();
        tavailable.setBounds(200,215,150,30);
        add(tavailable);

        JLabel name=new JLabel("Cleaning Status");
        name.setBounds(60,170,100,30);
        add(name);

        tstatus=new JTextField();
        tstatus.setBounds(200,170,150,30);
        add(tstatus);

//        JLabel depo=new JLabel("Amount Paid");
//        depo.setBounds(60,205,100,20);
//        add(depo);
//
//        tdepo=new JTextField();
//        tdepo.setBounds(200,205,150,20);
//        add(tdepo);
//
//        JLabel pending=new JLabel("Pending Amount");
//        pending.setBounds(60,235,100,20);
//        add(pending);
//
//        tpending=new JTextField();
//        tpending.setBounds(200,235  ,150,20);
//        add(tpending);

        check =new JButton("Check");
        check.setBackground(Color.BLACK);
        check.setForeground(Color.WHITE);
        check.addActionListener(this);
        check.setBounds(80,300  ,80,20);
        add(check);

        update =new JButton("Update");
        update.setBackground(Color.BLACK);
        update.setForeground(Color.WHITE);
        update.addActionListener(this);
        update.setBounds(180,300  ,80,20);
        add(update);


        back =new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(280,300 ,80,20);
        add(back);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/seventh.jpg"));
        Image i2=i1.getImage().getScaledInstance(500,300,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(450,30,500,300);
        add(img);

    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() ==  check){
            String id=customer.getSelectedItem();
            String query="select * from customer where number ='"+id+"'";
            try{
                conn c=new conn();
                ResultSet rs=c.s.executeQuery(query);
                while (rs.next()){
                    troomno.setText(rs.getString("room"));
                    //    tname.setText(rs.getString("name"));
                    //  checkintime2.setText(rs.getString("checkintime"));
                    //  tdepo.setText(rs.getString("entdeposite"));
                }

                ResultSet rs2=c.s.executeQuery("select * from room where roomno ='"+troomno.getText()+"'");
                while(rs2.next()){
                   tavailable.setText(rs2.getString("avaibility"));
                   tstatus.setText(rs2.getString("status"));
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }else if(e.getSource() == update) {

            String number=customer.getSelectedItem();
            String room=troomno.getText();
            String available=tavailable.getText();
            String status=tstatus.getText();
          //  String deposit=tdepo.getText();

            try{
                conn c3=new conn();
                c3.s.executeUpdate("update room set avaibility='" + available + "', status='" + status + "' WHERE roomno='" + room + "'");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(null,"Data update Successfully");
            setVisible(false);
            new Reception();

        } else if (e.getSource() == back) {
            setVisible(false);
            new Reception();

        }
    }


    public static void main(String[] args) {
        new UpdateRoom();
    }


}

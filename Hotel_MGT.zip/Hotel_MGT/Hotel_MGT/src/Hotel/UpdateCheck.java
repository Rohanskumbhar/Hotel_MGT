package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;


public class UpdateCheck extends JFrame implements ActionListener {

        Choice customer;
        JTextField troomno,tname,tdepo,tpending,checkintime2;
        JButton check,update,back;
    UpdateCheck(){
        setBounds(300,150,980,500);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);

        JLabel text=new JLabel("Update Status");
        text.setFont(new Font("Tahoma",Font.BOLD,25));
        text.setBounds(200,20,300,30);
        add(text);

        JLabel cust=new JLabel("Customer Id");
        cust.setBounds(60,75,100,20);
        add(cust);

        customer =new Choice();
        customer.setBounds(200,75,150,30);
        add(customer);

        try{
            conn c=new conn();
            ResultSet rs=c.s.executeQuery("select * from customer");
            while (rs.next()){
                customer.add(rs.getString("number"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        JLabel room=new JLabel("Room Number");
        room.setBounds(60,115,100,20);
        add(room);

        troomno=new JTextField();
        troomno.setBounds(200,115,150,20);
        add(troomno);

        JLabel checkin=new JLabel("Check In Time");
        checkin.setBounds(60,175,100,20);
        add(checkin);

        checkintime2=new JTextField();
        checkintime2.setBounds(200,175,150,20);
        add(checkintime2);

        JLabel name=new JLabel("Name");
        name.setBounds(60,145,100,20);
        add(name);

        tname=new JTextField();
        tname.setBounds(200,145,150,20);
        add(tname);

        JLabel depo=new JLabel("Amount Paid");
        depo.setBounds(60,205,100,20);
        add(depo);

        tdepo=new JTextField();
        tdepo.setBounds(200,205,150,20);
        add(tdepo);

        JLabel pending=new JLabel("Pending Amount");
        pending.setBounds(60,235,100,20);
        add(pending);

        tpending=new JTextField();
        tpending.setBounds(200,235  ,150,20);
        add(tpending);

        check =new JButton("Check");
        check.setBackground(Color.BLACK);
        check.setForeground(Color.WHITE);
        check.addActionListener(this);
        check.setBounds(80,320  ,80,20);
        add(check);

        update =new JButton("Update");
        update.setBackground(Color.BLACK);
        update.setForeground(Color.WHITE);
        update.addActionListener(this);
        update.setBounds(180,320  ,80,20);
        add(update);


        back =new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(280,320 ,80,20);
        add(back);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/nine.jpg"));
        JLabel img=new JLabel(i1);
        img.setBounds(400,30,500,300);
        add(img);

    }
    public void actionPerformed(ActionEvent e) {
            if (e.getSource() ==  check){
                String id=customer.getSelectedItem();
                String query="select * from customer where number ='"+id+"'";
                try{
                    conn c=new conn();
                    ResultSet rs=c.s.executeQuery(query);
                    while (rs.next()){
                        troomno.setText(rs.getString("room"));
                        tname.setText(rs.getString("name"));
                        checkintime2.setText(rs.getString("checkintime"));
                        tdepo.setText(rs.getString("entdeposite"));
                    }

                    ResultSet rs2=c.s.executeQuery("select * from room where roomno ='"+troomno.getText()+"'");
                    while(rs2.next()){
                        String price=rs2.getString("price");
                        int amountpaid=Integer.parseInt(price) - Integer.parseInt(tdepo.getText());
                        tpending.setText(""+amountpaid);
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }else if(e.getSource() == update) {

                String number=customer.getSelectedItem();
                String room=troomno.getText();
                String name=tname.getText();
                String checkin=checkintime2.getText();
                String deposit=tdepo.getText();

                try{
                    conn c3=new conn();
                    c3.s.executeUpdate("update customer set room='" + room + "', name='" + name + "', checkintime='" + checkin + "', entdeposite='" + deposit + "' WHERE number='" + number + "'");
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                JOptionPane.showMessageDialog(null,"Data update Successfully");
                setVisible(false);
                new Reception();

            } else if (e.getSource() == back) {
                setVisible(false);
                new Reception();

            }
    }


    public static void main(String[] args) {
            new UpdateCheck();
    }


}

package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame implements ActionListener {

    Dashboard(){

         setLayout(null);



         setBounds(0,0,1600,1000);
         setVisible(true);
         ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
         Image i2=i1.getImage().getScaledInstance(1600,1000,Image.SCALE_DEFAULT);
         ImageIcon i3=new ImageIcon(i2);
         JLabel img=new JLabel(i3);
         img.setBounds(0,0,1550,1000);
         add(img);

         JLabel text=new JLabel("The Pavilion Hotel Welcomes You!!!!!!!");
         text.setBounds(300,100,1000,100);
         text.setFont(new Font("Tahoma",Font.BOLD,50));
         text.setForeground(Color.BLACK);
         img.add(text);


         JMenuBar menu=new JMenuBar();
         menu.setBounds(0,0,1550,25);
         img.add(menu);


         JMenu hotel=new JMenu("HOTEL MANAGEMENT");
         hotel.setFont(new Font("Tahoma",Font.BOLD,20));
         hotel.setBackground(Color.LIGHT_GRAY);
         menu.add(hotel);

         JMenuItem reception=new JMenuItem("RECEPTION");
         reception.addActionListener(this);
         reception.setFont(new Font("Tahoma",Font.PLAIN,15));
         hotel.add(reception);




        JMenu admin=new JMenu("    ADMIN");
        admin.setFont(new Font("Tahoma",Font.BOLD,20));
        admin.setBackground(Color.LIGHT_GRAY);
        menu.add(admin);

        JMenuItem AddEmployee=new JMenuItem("ADD EMPLOYEE");
        AddEmployee.addActionListener(this);
        AddEmployee.setFont(new Font("Tahoma",Font.PLAIN,15));
        admin.add(AddEmployee);

        JMenuItem AddRooms=new JMenuItem("ADD ROOMS");
        AddRooms.addActionListener(this);
        AddRooms.setFont(new Font("Tahoma",Font.PLAIN,15));
        admin.add(AddRooms);

        JMenuItem AddDrives=new JMenuItem("ADD DRIVERS");
        AddDrives.addActionListener(this);
        AddDrives.setFont(new Font("Tahoma",Font.PLAIN,15));
        admin.add(AddDrives);
    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getActionCommand().equals("ADD EMPLOYEE")){
            new AddEmployee();
        } else if (ae.getActionCommand().equals("ADD ROOMS")) {
            new AddRooms();
        } else if (ae.getActionCommand().equals("ADD DRIVERS")) {
             new AddDrivers();
        }else if (ae.getActionCommand().equals("RECEPTION")){
                new Reception();
        }
    }


    public static void main(String[] args) {
        new Dashboard();
    }
}

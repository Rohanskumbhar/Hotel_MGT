package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddRooms extends JFrame implements ActionListener {
    JButton add,cancel;
    JTextField roomtext,roompricetext;
    JComboBox availableornot,cleanornot,bedtypes;

    AddRooms(){
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setBounds(200,100,1100,500);
        setVisible(true);

        JLabel heading =new JLabel("Add Rooms");
        heading.setFont(new Font("Tahoma",Font.BOLD,30));
        heading.setBounds(450,10,200,50);
        add(heading);

        //Room Start
        JLabel roomno =new JLabel("Rooms Number :- ");
        roomno.setFont(new Font("Tahoma",Font.PLAIN ,16));
        roomno.setBounds(80,70,160,30);
        add(roomno);

         roomtext=new JTextField();
        roomtext.setBounds(260,70,200,30);
        roomtext.setFont(new Font("Tahoma",Font.PLAIN ,14));
        add(roomtext);
        //Room End

        //Available or Not
        JLabel available =new JLabel("Available :- ");
        available.setFont(new Font("Tahoma",Font.PLAIN ,16));
        available.setBounds(80,110,160,30);
        add(available);

        String availableoptions[]={"Available","Occupied"};
         availableornot=new JComboBox(availableoptions);
        availableornot.setBounds(260,110,160,30);
        availableornot.setBackground(Color.WHITE);
        add(availableornot);

        //Clean or Not
        JLabel clean =new JLabel("Clean Status :- ");
        clean.setFont(new Font("Tahoma",Font.PLAIN ,16));
        clean.setBounds(80,150,160,30);
        add(clean);

        String cleanoptions[]={"Clean","Dirty"};
         cleanornot=new JComboBox(cleanoptions);
        cleanornot.setBounds(260,150,160,30);
        cleanornot.setBackground(Color.WHITE);
        add(cleanornot);


        //Room Price Start
        JLabel roomprice =new JLabel("Rooms Price :- ");
        roomprice.setFont(new Font("Tahoma",Font.PLAIN ,16));
        roomprice.setBounds(80,190,160,30);
        add(roomprice);

         roompricetext=new JTextField();
        roompricetext.setBounds(260,190,200,30);
        roompricetext.setFont(new Font("Tahoma",Font.PLAIN ,14));
        add(roompricetext);

        //Bed Type
        JLabel bed =new JLabel("Bed Type :- ");
        bed.setFont(new Font("Tahoma",Font.PLAIN ,16));
        bed.setBounds(80,230,160,30);
        add(bed);

        String bedoption[]={"Single","Double"};
         bedtypes=new JComboBox(bedoption);
        bedtypes.setBounds(260,230,160,30);
        bedtypes.setBackground(Color.WHITE);
        add(bedtypes);

         add=new JButton("Add Room");
        add.setForeground(Color.WHITE);
        add.setBackground(Color.BLACK);
        add.setBounds(150,280,100,30);
        add.addActionListener(this);
        add(add);

         cancel=new JButton("Cancel");
        cancel.setForeground(Color.WHITE);
        cancel.setBackground(Color.BLACK);
        cancel.setBounds(350,280,80,30);
        cancel.addActionListener(this);
        add(cancel);

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("icons/twelve.jpg"));
        JLabel img=new JLabel(i1);
        img.setBounds(500,70,500,350);
        add(img);


    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == add){
                String roomno=roomtext.getText();
                String avaibility=(String) availableornot.getSelectedItem();
                String status=(String) cleanornot.getSelectedItem();
                String price=roompricetext.getText();
                String type=(String) bedtypes.getSelectedItem();

                try {
                    conn con=new conn();

                    String query="insert into room values('"+roomno+"','"+avaibility+"','"+status+"','"+price+"','"+type+"') ";

                    con.s.executeUpdate(query);

                    JOptionPane.showMessageDialog(null,"New Room Added Successfully");
                    setVisible(false);


                } catch (Exception ex) {
                    ex.printStackTrace();
                }
        } else if (e.getSource() == cancel) {
                setVisible(false);
        }

    }

    public static void main(String[] args) {
        new AddRooms();
    }


}

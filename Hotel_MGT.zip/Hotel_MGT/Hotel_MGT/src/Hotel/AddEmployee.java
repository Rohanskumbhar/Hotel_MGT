package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
// Assuming you have a 'conn' class in this package or it needs to be imported/defined.
// For the code to compile and run the database part, you need to ensure 'conn' is accessible.

public class AddEmployee extends JFrame implements ActionListener {
    JTextField nametext,agetext,salarytext,phonetext,Emailtext,Aadhartext;
    JRadioButton male,female;
    JButton submit;
    JComboBox<String> jobbox; // Use generics for better type safety
    //  String jobposition;

    AddEmployee(){
        setLayout(null);

        //Name Start
        JLabel name=new JLabel("Name :-");
        name.setBounds(20,50,100,20);
        name.setFont(new Font("Tahoma",Font.BOLD,17));
        add(name);

        nametext=new JTextField();
        nametext.setBounds(150,50,200,20);
        add(nametext);
        //Name End


        //Age Start
        JLabel age=new JLabel("Age :-");
        age.setBounds(20,100,100,20);
        age.setFont(new Font("Tahoma",Font.BOLD,17));
        add(age);

        agetext=new JTextField();
        agetext .setBounds(150,100,200,20);
        add(agetext);
        //Age end


        //Gender Start
        JLabel gender=new JLabel("Gender :-");
        gender.setBounds(20,150,100,20);
        gender.setFont(new Font("Tahoma",Font.BOLD,17));
        add(gender);

        male=new JRadioButton("Male");
        male.setBounds(150,150,70,20);
        male.setBackground(Color.WHITE);
        add(male);

        female=new JRadioButton("Female");
        female.setBackground(Color.WHITE);
        female.setBounds(260,150,80,20);
        add(female);

        ButtonGroup bg=new ButtonGroup();
        bg.add(male);
        bg.add(female);
        //Gender End


        //Job Start
        JLabel job=new JLabel("Job :-");
        job.setBounds(20,200,100,20);
        job.setFont(new Font("Tahoma",Font.BOLD,17));
        add(job);

        String jobposition []={"Front Desk Clerk","Porters","HouseKeeping","Kitchen Staff","Room Services","Chefs","Guards","Receptionist","manager"}; //Add more positions in this array then show in Combobox
        jobbox=new JComboBox<>(jobposition); // Added type argument
        jobbox.setBounds(150,200,200,20);
        jobbox.setBackground(Color.WHITE);
        add(jobbox);
        //Job End


        //Salary Start
        JLabel salary=new JLabel("Salary  :-");
        salary.setBounds(20,250,100,20);
        salary.setFont(new Font("Tahoma",Font.BOLD,17));
        add(salary);

        salarytext=new JTextField();
        salarytext.setBounds(150,250,200,20);
        add(salarytext);
        //Salary End


        //Phone Start
        JLabel Phone=new JLabel("Phone :-");
        Phone.setBounds(20,300,100,20);
        Phone.setFont(new Font("Tahoma",Font.BOLD,17));
        add(Phone);

        phonetext=new JTextField();
        phonetext.setBounds(150,300,200,20);
        add(phonetext);
        //Phone End



        //E-mail Start
        JLabel Email=new JLabel("E-Mail :-");
        Email.setBounds(20,350,100,20);
        Email.setFont(new Font("Tahoma",Font.BOLD,17));
        add(Email);

        Emailtext=new JTextField();
        Emailtext.setBounds(150,350,200,20);
        add(Emailtext);
        //E-mail End


        //Aadhar Start
        JLabel Aadhar=new JLabel("Aadhaar :-");
        Aadhar.setBounds(20,400,100,20);
        Aadhar.setFont(new Font("Tahoma",Font.BOLD,17));
        add(Aadhar);

        Aadhartext=new JTextField();
        Aadhartext.setBounds(150,400,200,20);
        add(Aadhartext);
        //Aadhar End

        submit=new JButton("Submit");
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.setFont(new Font("plain",Font.BOLD,17));
        submit.setBounds(230,450,100,20);
        submit.addActionListener(this);
        add(submit);


        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/tenth.jpg"));
        Image i2=i1.getImage().getScaledInstance(300,300,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(370,100,300,250);
        add(img);




        getContentPane().setBackground(Color.WHITE);
        setBounds(500,120,700,550);
        setVisible(true);
        setTitle("Add Employee Details"); // Added title for clarity
    }

    // THIS IS THE CORRECT METHOD: actionPerformed (lowercase 'a')
    @Override
    public void actionPerformed(ActionEvent ae) {
        // The ActionEvent 'ae' is the one triggered by the submit button since 'this' (the frame)
        // was added as the ActionListener for the 'submit' button.

        // Removed the unnecessary ActionPerformance method and moved its body here.
        String name=nametext.getText();
        String age =agetext.getText();
        String salary=salarytext.getText();
        String phone=phonetext.getText();
        String email=Emailtext.getText();
        String aadhar=Aadhartext.getText();

        String gender=null;
        if(male.isSelected()){
            gender="Male";
        }else if(female.isSelected()){
            gender="Female";
        }

        String job=(String) jobbox.getSelectedItem();

        // Basic validation check (optional but recommended)
        if(name.isEmpty() || age.isEmpty() || salary.isEmpty() || phone.isEmpty() || email.isEmpty() || aadhar.isEmpty() || gender == null){
            JOptionPane.showMessageDialog(null,"Please fill all fields!");
            return;
        }

        try{

            conn c=new conn();

            String query="insert into employee values('"+name+"','"+age+"','"+gender+"','"+job+"','"+salary+"','"+phone+"','"+email+"','"+aadhar+"') ";

            c.s.executeUpdate(query);

            JOptionPane.showMessageDialog(null,"Employee Added Successfully");
            setVisible(false);

         //   setVisible(false);

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error adding employee: " + e.getMessage());
        }
    }


    public static void main(String[] args) {
        new AddEmployee();
    }
}
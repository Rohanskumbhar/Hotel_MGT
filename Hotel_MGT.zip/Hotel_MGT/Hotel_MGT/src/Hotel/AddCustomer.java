package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.util.Date;

public class AddCustomer extends JFrame implements ActionListener {
    JComboBox comboid;
    JTextField num,entname,entcountry,deposite;
    JRadioButton  male,female;
    Choice croom;
    JLabel checktime;
    JButton add,back;

    AddCustomer(){
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setBounds(450,100,800,550);

        setVisible(true);

        JLabel title= new JLabel("NEW CUSTOMER FORM");
        title.setBounds(150,10,360,40);
        title.setFont(new Font("Tahoma",Font.BOLD,30));
        add(title);

        //ID start
        JLabel id= new JLabel("ID :-");
        id.setBounds(50,60,70,30);
        id.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(id);

        String options[]={"Aadhar Card","PassPort","Driving License","Voter Card",};
        comboid =new JComboBox(options);
        comboid.setBackground(Color.WHITE);
        comboid.setBounds(170,58,150,30);
        add(comboid);


        //Num start
        JLabel number= new JLabel("Number :-");
        number.setBounds(50,100,100,30);
        number.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(number);

        num=new JTextField();
        num.setBounds(170,100,150,30);
        num.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(num);


        //Name Start
        JLabel name= new JLabel("Name:-");
        name.setBounds(50,150,100,30);
        name.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(name);

        entname=new JTextField();
        entname.setBounds(170,150,150,30);
        entname.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(entname);


        //Gender Start
        JLabel gender=new JLabel("Gender :-");
        gender.setBounds(50,200,100,30);
        gender.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(gender);

        male=new JRadioButton("Male");
        male.setBounds(180,200,65,30);
        male.setBackground(Color.WHITE);
        add(male);

        female=new JRadioButton("Female");
        female.setBackground(Color.WHITE);
        female.setBounds(245,200,80,30);
        add(female);

        ButtonGroup bg=new ButtonGroup();
        bg.add(male);
        bg.add(female);
        //Gender End


        //Country Start
        JLabel country= new JLabel("Country :-");
        country.setBounds(50,240,140,30);
        country.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(country);

        entcountry=new JTextField();
        entcountry.setBounds(170,240,150,30);
        entcountry.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(entcountry);



        //Allocated Room no
        JLabel roomno= new JLabel("Room No :-");
        roomno.setBounds(50,280,120,30);
        roomno.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(roomno);

        croom=new Choice();
        try {
            conn con =new conn();
            String query="select * from room where avaibility='Available'";
            con.s.executeQuery(query);
            ResultSet rs=con.s.executeQuery(query);
            while(rs.next()){
                croom.add(rs.getString("roomno"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        croom.setBounds(170,280,140,60);
        croom.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(croom);


        //date time
        JLabel lbltime= new JLabel("Time :-");
        lbltime.setBounds(50,320,180,30);
        lbltime.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(lbltime);


        Date date = new Date();
        checktime= new JLabel(" " +date);
        checktime.setBounds(170,320,185,30);
        checktime.setFont(new Font("Tahoma",Font.BOLD,15));
        add(checktime);


        //Deposite Start
        JLabel depo= new JLabel("Deposit :-");
        depo.setBounds(50,360,140,30);
        depo.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(depo);

        deposite=new JTextField();
        deposite.setBounds(170,360,150,30);
        deposite.setFont(new Font("Tahoma",Font.PLAIN,20));
        add(deposite);


        //Buttons
         add=new JButton("Add");
         add.setBackground(Color.BLACK);
         add.setForeground(Color.WHITE);
         add.setBounds(100,420,80,30);
         add.addActionListener(this);
         add(add);

        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setBounds(250,420,80,30);
        back.addActionListener(this);
        add(back);

        //Image
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/fifth.png"));
        Image i2=i1.getImage().getScaledInstance(400,300,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(350,80,400,300);
        add(img);

    }
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == add){
            String id=(String)comboid.getSelectedItem();
            String number=num.getText();
            String name=entname.getText();
            String gender=null;

            if (male.isSelected()){
                gender="Male";
            } else if (female.isSelected()) {
                gender="Female";
            }
            String country=entcountry.getText();
            String room=croom.getSelectedItem();
            String checkintime=checktime.getText();
            String entdeposite=deposite.getText();

            try {
                    String query="insert into customer values('"+id+"','"+number+"','"+name+"','"+gender+"','"+country+"','"+room+"','"+checkintime+"','"+entdeposite+"') ";
                    String query2="update room set avaibility='occupied' where roomno='"+room+"'";

                    conn con=new conn();
                    con.s.executeUpdate(query);
                    con.s.executeUpdate(query2);

                    JOptionPane.showMessageDialog(null,"New Customer Added Successfully");
                    setVisible(false);
                    new Reception();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }else if (e.getSource() == back){
            setVisible(false);
            new Reception();
        }
    }

    public static void main(String[] args) {
        new AddCustomer();
    }


}

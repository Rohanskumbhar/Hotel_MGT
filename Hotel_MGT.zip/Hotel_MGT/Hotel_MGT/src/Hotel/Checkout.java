package Hotel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.sql.ResultSet;

public class Checkout extends JFrame implements ActionListener {
    Choice customerid;
    JLabel roomno1,checkintime1,checkouttime;
    JButton checkoutbut,back;
    Checkout(){
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setBounds(400,200,800,400);
        setVisible(true);

        JLabel text=new JLabel("Checkout");
        text.setFont(new Font("Tahoma",Font.BOLD,30));
        text.setBounds(100,20,200,30);
        add(text);

        JLabel custid=new JLabel("Customer Id");
        custid.setBounds(40,60,100,30);
        add(custid);

        customerid =new Choice();
        customerid.setBounds(150,65,150,30);
        add(customerid);



        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/tick.png"));
        Image i2=i1.getImage().getScaledInstance(20,20,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel img=new JLabel(i3);
        img.setBounds(310,65,20,20);
        add(img);

        JLabel room=new JLabel("Room No");
        room.setBounds(40,100,100,30);
        add(room);

        roomno1=new JLabel("");
        roomno1.setBounds(150,100,100,30);
        add(roomno1);

        JLabel checkin =new JLabel("Check in time");
        checkin.setBounds(40,150,100,30);
        add(checkin);

        checkintime1=new JLabel("");
        checkintime1.setBounds(150,150,100,30);
        add(checkintime1);

        JLabel checkout =new JLabel("Check out time");
        checkout.setBounds(40,200,100,30);
        add(checkout);

        Date date = new Date();
        checkouttime=new JLabel(""+date);
        checkouttime.setBounds(150,200,250,30);
        add(checkouttime);

        checkoutbut=new JButton("Checkout");
        checkoutbut.setBackground(Color.BLACK);
        checkoutbut.setForeground(Color.WHITE);
        checkoutbut.addActionListener(this);
        checkoutbut.setBounds(80,250,100,30);
        add(checkoutbut);


        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(200,250,100,30);
        add(back);

        try{
            conn c=new conn();
            ResultSet rs=c.s.executeQuery("select * from customer");
            while (rs.next()){
                customerid.add(rs.getString("number"));
                checkintime1.setText(rs.getString("checkintime"));
                roomno1.setText(rs.getString("room"));

            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        ImageIcon i4=new ImageIcon(ClassLoader.getSystemResource("icons/sixth.jpg"));
        Image i5=i4.getImage().getScaledInstance(400,250,Image.SCALE_DEFAULT);
        ImageIcon i6=new ImageIcon(i5);
        JLabel img1=new JLabel(i6);
        img1.setBounds(350,50,400,250);
        add(img1);


    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == checkoutbut){
            String query="delete from customer where number='"+customerid.getSelectedItem()+"'";
            String query2="update room set avaibility='Available' where roomno='"+roomno1.getText()+"'";


            try{
                conn c=new conn();
                c.s.executeUpdate(query);
                c.s.executeUpdate(query2);

                JOptionPane.showMessageDialog(null,"Checkout Done");
                setVisible(false);
                new Reception();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == back) {
            setVisible(false);
            new Reception();
        }
    }


    public static void main(String[] args) {
        new Checkout();
    }

}
